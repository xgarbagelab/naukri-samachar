<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
        Department Name: <input type="text" name="department" id="department"><br>
        Post: <input type="text" name="post" id="post"><br>
        State: <input type="text" name ="state" id ="state"><br>
        Number of Vacancies: <input type="text" name ="vacancies" id ="vacancies"></br>
        Age Limit:<input type="text" name="agelimit" id="agelimit"></br>
        Educational Qualification: <input type="text" name="eligibility" id="eligibility"></br>
        Pay Scale: <input type="input" name="salary" id="salary"></br>
        Selection Process: <input type="input" name="selection_process" id="selection_process"></br>
        
    </body>
</html>
